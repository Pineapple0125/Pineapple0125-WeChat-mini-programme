const cloud = require('wx-server-sdk');

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});
const db = cloud.database();

exports.insertImage = async (event, context) => {
  try{
    const result = await db.collection("image").add({
      data:{
        id:0, 
        image:"https://s1.ax1x.com/2023/01/31/pS0c7m8.jpg", 
        text:"畅游潮韵民间"
      }
    });
    return{
      code:0,
      message: "Data inserted succesfully",
      insertedId: result._id
    }
  }catch(err){
    return{
      code:-1,
      message: 'Data insertion failed:' + err.message
    }
  }
};