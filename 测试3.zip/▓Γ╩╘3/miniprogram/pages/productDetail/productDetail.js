
import * as THREE from '../../miniprogramThree/test1/threejs/three.weapp.js';
import { OrbitControls } from '../../miniprogramThree/test1/controls/OrbitControls.js';
import { GLTFLoader } from '../../miniprogramThree/test1/loaders/GLTFLoader.js';
import {OBJLoader} from '../../miniprogramThree/test1/loaders/OBJLoader.js'
import {MTLLoader} from '../../miniprogramThree/test1/loaders/MTLLoader.js'

Page({
  data: {},
  onLoad: function () {
    // 创建选择器查询
    wx.createSelectorQuery()
      .select('#c') // 选择 Canvas 元素
      .node()
      .exec((res) => {
        // 注册 Canvas
        const canvas = THREE.global.registerCanvas(res[0].node)
        
        // 将 Canvas 的 _canvasId 存储在 data 中
        this.setData({ canvasId: canvas._canvasId })

        // 创建透视相机
        const camera = new THREE.PerspectiveCamera(70, canvas.width / canvas.height, 1, 1000);
        camera.position.z = 500;

        // 创建场景
        const scene = new THREE.Scene();
        scene.background = new THREE.Color(0xAAAAAA);

        // 创建渲染器
        const renderer = new THREE.WebGLRenderer({ antialias: true });

        // 创建轨道控制器
        const controls = new OrbitControls(camera, renderer.domElement);
        // 控制器设置（可选）
        // controls.enableDamping = true;
        // controls.dampingFactor = 0.25;
        // controls.enableZoom = false;

        // 设置相机位置
        camera.position.set(200, 200, 500);
        controls.update();

        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.5);
        directionalLight.position.set(0, 0, 1); // 设置光源位置
        scene.add(directionalLight);

        const ambientLight = new THREE.AmbientLight(0xffffff, 0.5); // 选择适当的颜色
        scene.add(ambientLight);


        // 创建立方体的几何和材质
        const geometry = new THREE.BoxBufferGeometry(200, 200, 200);
        const material = new THREE.MeshBasicMaterial({ color: 0x44aa88 });
        
        // 创建立方体并添加到场景
        // const mesh = new THREE.Mesh(geometry, material);
        // scene.add(mesh);

        let mtlLoader = new MTLLoader();
        mtlLoader.load("https://7069-pineapple-2gzyo2k662e96f3a-1317145063.tcb.qcloud.la/model/%E6%97%A0%E6%A0%87%E9%A2%98.mtl?sign=c37a23b7b9eb4a55d406a230abc3e888&t=1709124785", function(materials){
          materials.preload();
          const loader = new OBJLoader();
          loader.setMaterials(materials)
          loader.load('https://7069-pineapple-2gzyo2k662e96f3a-1317145063.tcb.qcloud.la/model/%E6%97%A0%E6%A0%87%E9%A2%98.obj?sign=4daf0dedbea74c31ef28fb1830334a3f&t=1709126152', function (obj) {
          var model = obj;
          model.scale.set(6400,6400,6400)
          // var model = obj.scene
          // model.scale.set(64,64,64)
          scene.add(obj);
          }, undefined, function (e) {
            console.error(e);
          });

        });
        
        



        // 窗口大小变化时的回调函数
        function onWindowResize() {
          camera.aspect = canvas.width / canvas.height;
          camera.updateProjectionMatrix();
          renderer.setSize(canvas.width, canvas.height);
        }

        // 渲染函数
        function render() {
          canvas.requestAnimationFrame(render);
          // mesh.rotation.x += 0.005;
          // mesh.rotation.y += 0.01;
          controls.update();
          renderer.render(scene, camera);
        }

        // 启动渲染循环
        render()
      })
  },
  onUnload: function () {
    // 在页面卸载时注销 Canvas
    THREE.global.unregisterCanvas(this.data.canvasId)
  },
  // 触摸事件处理
  touchStart(e) {
    // console.log('canvas', e)
    THREE.global.touchEventHandlerFactory('canvas', 'touchstart')(e)
  },
  touchMove(e) {
    // console.log('canvas', e)
    THREE.global.touchEventHandlerFactory('canvas', 'touchmove')(e)
  },
  touchEnd(e) {
    // console.log('canvas', e)
    THREE.global.touchEventHandlerFactory('canvas', 'touchend')(e)
  },
  touchCancel(e) {
    // console.log('canvas', e)
  },
  // 其他触摸事件
  longTap(e) {
    // console.log('canvas', e)
  },
  tap(e) {
    // console.log('canvas', e)
  },
  // 文档级别触摸事件
  documentTouchStart(e) {
    // console.log('document',e)
  },
  documentTouchMove(e) {
    // console.log('document',e)
  },
  documentTouchEnd(e) {
    // console.log('document',e)
  },
})
