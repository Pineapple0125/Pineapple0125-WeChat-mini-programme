const db = wx.cloud.database()  // 初始化

Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 滚动切换标签样式
    interval: 5000,
    duration: 500,
    currentTab: 0, //预设当前项的值
    scrollLeft: 0, //tab标题的滚动条位置
    products:[],
    filteredProducts: [], // 用于存储过滤后的商品数据
  },

  // 点击标题切换当前页时改变样式
  switchNav: function(e) {
    // console.log(e)
    var cur = e.currentTarget.dataset.current; //查询标题序号
    console.log(cur)


    if (this.data.currentTab == cur) {
      return false;
    } else {

      const curMappings = {
        0: "mask",
        1: "keychain",
        2: "fan"
      };
      const type = curMappings[cur];
      filteredProducts: [],
      this.setData({
        currentTab: cur,
        filteredProducts: this.data.products.filter(item => item.type === String(type)),
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    db.collection('products').get().then(res => {
      // 查询成功，将结果赋值给product变量
      this.data.products = res.data
      console.log(this.data.products)
      const target = this.data.products;
      console.log(target);  
      const tabMappings = {  /*很帅的映射阿*/ 
        0: "mask",
        1: "keychain",
        2: "fan"
      };
      var currentTabTemp = tabMappings[this.data.currentTab];
      

      console.log(currentTabTemp)
      console.log("hhhhhhhhhhh")
      this.setData({
        // products: tempProduct,
        currentTab: tabMappings[target],
        filteredProducts: this.data.products.filter(item => item.type === String(currentTabTemp))
      });    
      console.log(this.data.filteredProducts)
    }).catch(err => {
      // 查询失败，输出错误信息
      console.error('查询失败', err)
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})