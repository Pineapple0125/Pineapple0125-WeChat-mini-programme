const db = wx.cloud.database()  // 初始化

Page({

  /**
   * 页面的初始数据
   */
  data: {
    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    console.log(options.index)
    console.log(options.type)
    var productText = ""
    db.collection(options.type).where({
      index: options.index
    }).get().then(res => {
      // 获取查询结果数组
      const result = res.data;
      if (result.length > 0) {
        // 如果找到匹配的对象，则将其 productText 内容存储到 data 中
        productText = result[0].productText
        console.log(productText)
  
        // this.productText='<T>潮剧，是中国传统地方戏曲之一，起源于广东省潮州地区，被誉为中国南方的“曲艺明珠”。潮剧以其婉转动听的曲调、精湛的表演技艺和独特的地方特色而闻名于世。下面是对潮剧的介绍：。///<H>起源与历史///<T>潮剧的历史可追溯至宋代，兴盛于明清时期，至今已有数百年的历史。它的发展离不开广东潮汕地区的文化底蕴和民间艺人的辛勤努力，融合了南音、吴戏、评弹等多种戏曲元素，形成了独具一格的艺术风格。///<H>特点与表演形式///<W>音乐特色///<T>潮剧音乐婉转动听，以悠扬的曲调和细腻的节奏为特色，常常能引人入胜，令人陶醉。///<W>表演技艺///<T>潮剧注重嗓音的运用和肢体语言的表达，演员常常要经过长期的专业训练才能掌握其独特的表演技巧。///<W>服饰道具///<T>潮剧的服饰华丽多彩，道具丰富多样，舞台装置精美，营造出丰富的舞台氛围。///<H>影响与传承///<T>潮剧在中国南方地区影响深远，不仅受到广大观众的喜爱，还为中国戏曲文化的传承与发展做出了重要贡献。近年来，随着中国文化产业的蓬勃发展，潮剧也逐渐走出国门，受到国际上越来越多的关注和欢迎。///<H>结语 ///<T>潮剧作为中国传统戏曲文化的重要组成部分，不仅是一种艺术形式，更是中国文化的瑰宝之一。通过其独特的表演风格和丰富的艺术内涵，潮剧将继续在舞台上绽放光彩，为世人带来无尽的艺术享受和思想启迪。///<P>https://s1.ax1x.com/2023/01/31/pS0c7m8.jpg';
    
{/* <T>🎭 绚丽潮剧，缤纷之美，尽在特色扇子之间 🎭///<P>cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/文创实拍/纸扇/2024-02-19 102319.jpg///<T>🌟 融合传统工艺与现代设计，我们的特色扇子将为您呈现出别样的视觉盛宴！ 🌟///<P>cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/文创实拍/纸扇/2024-02-19 102359.jpg///<T>🎨 设计独特：每一把特色扇子都蕴含着设计师的心血，精选丝绸与竹骨，精雕细琢而成，融合了传统的潮剧元素与现代的时尚审美，呈现出独特的艺术魅力。///<P>cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/文创实拍/纸扇/2024-02-19 102402.jpg///<T>🌺 巧夺天工：我们的特色扇子不仅在设计上别具匠心，在制作工艺上更是精益求精。每一道工序都经过精心打磨，力求将最完美的作品呈现给您。///<P>cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/文创实拍/纸扇/2024-02-19 102406.jpg///<T>💃 舞动风云：特色扇子不仅仅是一件道具，更是潮剧表演的灵魂之一。在舞台上，扇子的翻飞、摇曳，与演员的动作相得益彰，勾勒出一个个精彩绝伦的舞台画面，让观众沉浸其中，仿佛置身于另一个世界。///<T>🎭 独树一帜的设计，完美呈现的工艺，潮剧特色扇子，将为您的表演带来无限惊喜与感动！快来体验潮剧之美，感受特色扇子的独特魅力吧！🎭 */}
/** 
<T>🔑 时尚搭配，从钥匙扣开始 🔑///<T>💫 随身携带，方便实用，我们的钥匙扣不仅是钥匙的守护者，更是你个性的标志！ 💫///<P>cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/文创实拍/钥匙扣/2024-02-19 102320.jpg///<T>🎨 设计创意：每一款钥匙扣都由设计师精心打造，独特的造型、创意的图案，以及丰富的材质选择，让您的钥匙扣成为了时尚潮流中的一道亮丽风景线。
///<P>cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/文创实拍/钥匙扣/2024-02-19 102330.jpg///<T>🔒 守护您的钥匙：我们的钥匙扣不仅仅是一个配饰，更是对您重要物品的守护者。坚固的材质、精湛的工艺，让您的钥匙始终安全可靠，再也不必担心丢失！
///<P>cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/文创实拍/钥匙扣/2024-02-19 102345.jpg///<T>🎁 精美礼物：无论是送给自己还是送给朋友，我们的钥匙扣都是一份独特的礼物选择。让您的生活更加精彩，让您的关系更加紧密！
///<P>cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/文创实拍/钥匙扣/2024-02-19 102352.jpg///<T>🔑 踏上时尚之路，从我们的钥匙扣开始！让它成为您生活的一部分，彰显您的个性，承载您的回忆！🔑
*/




/**
<T>😷 健康防护，时尚潮流，从口罩开始 😷///<P>cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/文创实拍/口罩/2024-02-19 102317.jpg///<T>🌟 舒适贴合，时尚设计，我们的口罩将为您带来全新的防护体验！ 🌟///<P>cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/文创实拍/口罩/2024-02-19 102318.jpg
///<T>🎨 设计创新：我们的口罩不仅仅是一件防护用品，更是您时尚生活的一部分。各种时尚设计、独特图案，让您在防护的同时也能展现出个性魅力！///<P>cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/文创实拍/口罩/2024-02-19 102331.jpg///<T>🌿 健康舒适：采用高品质面料，舒适透气，贴合面部轮廓，让您在佩戴口罩的同时享受健康舒适的感觉，让呼吸更加畅快！///<P>cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/文创实拍/口罩/2024-02-19 102334.jpg///<T>🎁 时尚礼物：口罩不仅是健康防护的必备品，更是一份独特的时尚礼物。送给自己或送给亲朋好友，都能传递出关爱与美好！///<P>cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/文创实拍/口罩/2024-02-19 102338.jpg///<T>😷 追求时尚，从我们的口罩开始！让健康防护也能成为时尚潮流的一部分，让我们一起为美好的未来而努力！😷///<P>cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/文创实拍/口罩/2024-02-19 102342.jpg
  
 */


        var productStr=productText;
        console.log(productStr)
        const contentArray=productStr.split('///');
        const contentArrayLength=contentArray.length;
        var LoopArray = []; 
        for(var i=0;i<contentArrayLength;i++)
        {
           var content=contentArray[i];
           console.log(content)
           var item = {};
           var startString='<';
           var endString='>';
           var rexStr='(?<='+startString+').*?(?='+endString+')';
           var regex = new RegExp(rexStr);
           var match = content.match(regex);
           var matchVal = match[0];
           var matchLength=matchVal.length;
           content=content.substring(matchLength+2,content.length);
          //  if(matchVal=='P')content='images/'+detail+'/'+content+'.jpg';
           item.tag=matchVal;       
           item.content=content;
           LoopArray.push(item);
          }
          this.setData({
            LoopArray: LoopArray,
          });

      } else {
        // 如果未找到匹配的对象，给出相应提示
        console.log('未找到匹配的对象');
      }
    }).catch(err => {
      console.error('查询失败', err);
    });

    // console.log(productText)
  
    // // this.productText='<T>潮剧，是中国传统地方戏曲之一，起源于广东省潮州地区，被誉为中国南方的“曲艺明珠”。潮剧以其婉转动听的曲调、精湛的表演技艺和独特的地方特色而闻名于世。下面是对潮剧的介绍：。///<H>起源与历史///<T>潮剧的历史可追溯至宋代，兴盛于明清时期，至今已有数百年的历史。它的发展离不开广东潮汕地区的文化底蕴和民间艺人的辛勤努力，融合了南音、吴戏、评弹等多种戏曲元素，形成了独具一格的艺术风格。///<H>特点与表演形式///<W>音乐特色///<T>潮剧音乐婉转动听，以悠扬的曲调和细腻的节奏为特色，常常能引人入胜，令人陶醉。///<W>表演技艺///<T>潮剧注重嗓音的运用和肢体语言的表达，演员常常要经过长期的专业训练才能掌握其独特的表演技巧。///<W>服饰道具///<T>潮剧的服饰华丽多彩，道具丰富多样，舞台装置精美，营造出丰富的舞台氛围。///<H>影响与传承///<T>潮剧在中国南方地区影响深远，不仅受到广大观众的喜爱，还为中国戏曲文化的传承与发展做出了重要贡献。近年来，随着中国文化产业的蓬勃发展，潮剧也逐渐走出国门，受到国际上越来越多的关注和欢迎。///<H>结语 ///<T>潮剧作为中国传统戏曲文化的重要组成部分，不仅是一种艺术形式，更是中国文化的瑰宝之一。通过其独特的表演风格和丰富的艺术内涵，潮剧将继续在舞台上绽放光彩，为世人带来无尽的艺术享受和思想启迪。///<P>https://s1.ax1x.com/2023/01/31/pS0c7m8.jpg';

    // var productStr=this.productText;
    // console.log(productStr)
    // const contentArray=productStr.split('///');
    // const contentArrayLength=contentArray.length;
    // var LoopArray = []; 
    // for(var i=0;i<contentArrayLength;i++)
    // {
    //    var content=contentArray[i];
    //    console.log(content)
    //    var item = {};
    //    var startString='<';
    //    var endString='>';
    //    var rexStr='(?<='+startString+').*?(?='+endString+')';
    //    var regex = new RegExp(rexStr);
    //    var match = content.match(regex);
    //    var matchVal = match[0];
    //    var matchLength=matchVal.length;
    //    content=content.substring(matchLength+2,content.length);
    //   //  if(matchVal=='P')content='images/'+detail+'/'+content+'.jpg';
    //    item.tag=matchVal;       
    //    item.content=content;
    //    LoopArray.push(item);


      //  console.log(content)
      //  console.log(matchVal)
      //  if (matchVal == 'P') {
      //   // 根据 content 从数据库中查找名为 lnm 的图片
      //   db.collection('images').where({
      //     name: content,
      //     // 假设数据库中存储图片路径的字段为 imageUrl
      //   }).get().then(res => {
      //     if (res.data.length > 0) {
      //       // 找到图片，设置为 content
      //       console.log("test")
      //       content = res.data[0].imageUrl;
      //       item.tag='P';  
      //       item.content = "https://s1.ax1x.com/2023/01/31/pS0c7m8.jpg";
      //       LoopArray.push(item);
 
      //     }
          
      //   }).catch(err => {
      //     // 处理数据库查询错误
      //     console.error('查询数据库失败：', err);
      //     console.log("error")
      //   });
      // }else {
      //   // 如果标签不是 P，则直接将 content 设置为原始内容
      //   item.tag=matchVal;  
      //   item.content = content;
      //   LoopArray.push(item);
      // }

    // }
    // this.setData({
    //   LoopArray: LoopArray,
    // });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})