// pages/me/me.js
Page({

  onHistoryJump:function(event){
    wx.navigateTo({
      url: '../history/history',
      success:function(){
        console.log("jump!!")
      }
    })
  },

  onFavouriteJump:function(event){
    wx.navigateTo({
      url: '../favorite/favorite',
      success:function(){
        console.log("jump")
      }
    })
  },

  onPersonalDataJump:function(event){
    wx.navigateTo({
      url: '../personalData/personalData',
      success:function(){
        console.log("jump!!")
      }
    })
  },


  /**
   * 页面的初始数据
   */
  data: {
    row_slide_list:[
      {id:0, image:"cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/icon/购物车.png", text:"购物车", url:""},
      {id:1, image:"cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/icon/待收货.png", text:"待收货",url:""},
      {id:2, image:"cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/icon/待评价.png", text:"待评价", url:""},
      {id:3, image:"cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/icon/全部订单.png", text:"全部订单", url:""},
    ],

    userInfo: {},
    hasUserInfo: false,
    canIUseGetUserProfile: false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  // onLoad(options) {
  //   if (wx.getUserProfile) {
  //     this.setData({
  //       canIUseGetUserProfile: true
  //     })
  //   }

  //   if (!wx.getStorageSync('hadAuthed')) {
                
  //     // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
  //     // An highlighted block
  //     wx.showModal({
  //       title: '温馨提示',
  //       content: '正在请求获取您的个人信息，以后续方便使用本程序！',
  //       success(res) {
  //         if (res.confirm) {
  //           wx.getUserProfile({
  //             desc: "获取你的昵称、头像、地区及性别",
  //             success: res => {
  //               // app.globalData.userInfo =  data
  //               wx.setStorageSync('userInfo', data)
  //               wx.setStorageSync('hadAuthed', true)
  //               // wx.getStorageSync('hadAuthed')

  //                //这里可以发起获取token的请求
                
  //               // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
  //               // 所以此处加入 callback 以防止这种情况
  //               // callback && callback(res);
  //             },
  //             fail: res => {
  //               //拒绝授权
  //               // that.showErrorModal('您拒绝了请求');
  //               wx.showToast({
  //                 title: '授权失败',
  //                 icon: 'none',
  //                 duration: 1000
  //               })
  //               return;
  //             }
  //           })
  //         } else if (res.cancel) {
  //           wx.showToast({
  //             title: '授权失败',
  //             icon: 'none',
  //             duration: 1000
  //           })
  //           //拒绝授权 showErrorModal是自定义的提示
  //           // that.showErrorModal('您拒绝了请求');
  //           return;
  //         }
  //       }
  //     })
  //   }


  // },

  getUserProfile(e) {
    // 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认
    // 开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
    wx.getUserProfile({
      desc: '用于完善会员资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success: (res) => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    })
  },
  getUserInfo(e) {
    // 不推荐使用getUserInfo获取用户信息，预计自2021年4月13日起，getUserInfo将不再弹出弹窗，并直接返回匿名的用户个人信息
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },

  showServer(){
    wx.showModal({
      title: '温馨提示',
      content: '本程序由潮韵继往项目组开发'
    })
  },



  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})