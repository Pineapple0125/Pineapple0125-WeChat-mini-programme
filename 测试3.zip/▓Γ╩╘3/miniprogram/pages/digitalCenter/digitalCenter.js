const query = wx.createSelectorQuery()	//选取wxml的dom元素
let systemInfo = wx.getSystemInfoSync(); //获取屏幕的尺寸大小
const db = wx.cloud.database()  // 初始化

Page({

  /**
   * 页面的初始数据
   */
  data: {
    tabList:[
      {index:0,title:"历史文脉",imageUrl:"cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/icon/文化馆内/icon_rt_1.png"},
      {index:1,title:"经典剧目",imageUrl:"cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/icon/文化馆内/资源 25.png"},
      {index:2,title:"发展历史",imageUrl:"cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/icon/文化馆内/发展历史.png"},
      {index:3,title:"发展现状",imageUrl:"cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/icon/文化馆内/xingfu-01.png"},
      {index:4,title:"文物古迹",imageUrl:"cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/icon/文化馆内/文物古迹.png"},
      {index:5,title:"传奇人物",imageUrl:"cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/icon/文化馆内/戏曲相声.png"},

    ],
    index:0,
    nowleft:0,	//scroll往左走多少
    nowselect:0	,

    history: [],
    classicalDrama:[],
    developmentHis:[],
    developmentRec:[],
    relicAndsites:[],
    legendGuys:[],
    creation:[],
    filteredProducts: [], // 用于存储过滤后的商品数据

  },

  // 点击标题切换当前页时改变样式
  switchNav: function(e) {
    console.log("switch")
    var cur = this.data.nowselect; //查询标题序号
    console.log(cur)
    console.log(this.data.index)
    if (this.data.index == cur) {
      return false;
    } else {
      this.setData({
        filteredProducts: [],
        index:this.data.nowselect,
      })
      console.log(this.data.nowselect)
      console.log(this.data.filteredProducts)

      var mapping = {
        0: this.data.history,
        1: this.data.classicalDrama,
        2: this.data.developmentHis,
        3: this.data.developmentRec,
        4: this.data.relicAndsites,
        5: this.data.legendGuys,
        6: this.data.creation,
      };

      var goal = mapping[this.data.nowselect]

      this.setData({
        currentTab: cur,
        filteredProducts: goal,
      })
      console.log(this.data.filteredProducts)
    }
  },

getProductList(e){
  console.log(e.currentTarget.dataset.index);
  console.log(this.data.windowWidth);
  let proportion = this.data.windowWidth/375; 
  //真机调试得出每个手机屏幕不同，我在微信工具这里满屏是375，在真机iphone11那里是414所以要获取屏幕宽度除以375获取比例
  let index = e.currentTarget.dataset.index
  let length = this.data.tabList.length //获取当前有多少个按钮
  this.setData({nowselect:index-1}) //获取当前的Index
  if(length>5){//长度必须超过5才可以用
    if(index<=3){ //由于我这个组件从1开始所以是小于等于3，从0开始的话就小于2
      this.setData({nowleft:0})
    }
    else if(index>=length - 2){//由于我这个组件从1开始所以是大于等于length - 2，从0开始的话就小于大于等于length - 3
      this.setData({nowleft:75*(length-5)*proportion})  //让倒数第三个在中间
    }
    else{
      this.setData({nowleft:75*(index-3)*proportion}) //让现在点击的在中间
    }
  }
  // this.setData({nowleft:75*(index-1)})
  console.log(this.data.nowleft);
},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    const collections = [
      'D_history',
      'D_classicalDrama',
      'D_creation',
      'D_developmentHis',
      'D_developmentRec',
      'D_legendGuys',
      'D_relicAndsites'
    ];

    db.collection("digitalCenter").get().then(res => {
      console.log(res.data);
    })

    collections.forEach(collection => {
      console.log(collection)
      db.collection(collection).get().then(res => {
        console.log(res.data);
        // 根据集合名称设置对应的数据
        switch (collection) {
          case 'D_history':
            this.setData({
              history: res.data,
              filteredProducts: res.data
            });
            break;
          case 'D_classicalDrama':
            this.setData({
              classicalDrama: res.data
            });
            break;
          case 'D_creation':
            this.setData({
              creation: res.data
            });
            break;
          case 'D_developmentHis':
            this.setData({
              developmentHis: res.data
            });
            break;
          case 'D_developmentRec':
            this.setData({
              developmentRec: res.data
            });
            break;
          case 'D_legendGuys':
            this.setData({
              legendGuys: res.data
            });
            break;
          case 'D_relicAndsites':
            this.setData({
              relicAndsites: res.data
            })
          default:
            break;
        }
      }).catch(err => {
        // 查询失败，输出错误信息
        console.error('查询失败', err);
      });
    });


    this.setData({
			windowHeight: systemInfo.windowHeight - 35,
			windowWidth: systemInfo.windowWidth,
		})
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})