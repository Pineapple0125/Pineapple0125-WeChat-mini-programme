const db = wx.cloud.database()  // 初始化
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgUrls: [
      'cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/infomationPicture/creation/7-1-1.png',
      'cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/infomationPicture/creation/7-1-2.png',
      'cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/infomationPicture/creation/7-2.png',
      'cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/infomationPicture/creation/7-3-1.png',
      'cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/infomationPicture/creation/7-3-2.png',
      "cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/infomationPicture/creation/7-4.png"
    ],
    indicatorDots: false, //是否显示面板指示点
    autoplay: true, //是否自动播放
    interval: 3000, //停留时间间隔
    duration: 1000, //播放时长
    previousMargin: '50px', //前边距，可用于露出前一项的一小部分，接受 px 和 rpx 值
    nextMargin: '50px', //后边距，可用于露出后一项的一小部分，接受 px 和 rpx 值
    circular: true, //是否采用衔接滑动
    currentSwiperIndex: 0, //swiper当前索引
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    console.log(options.index)
    console.log(options.type)
    
    var productText = ""
    db.collection(options.type).where({
      index: options.index
    }).get().then(res => {
      // 获取查询结果数组
      const result = res.data;
      if (result.length > 0) {
        // 如果找到匹配的对象，则将其 productText 内容存储到 data 中
        console.log(result[0])
        let title = result[0].title
        productText = result[0].productText
        console.log(productText)
        var productStr=productText;
        console.log(productStr)
        const contentArray=productStr.split('///');
        const contentArrayLength=contentArray.length;
        var LoopArray = []; 

        for(var i=0;i<contentArrayLength;i++)
        {
           var content=contentArray[i];
           console.log(content)
           var item = {};
           var startString='<';
           var endString='>';
           var rexStr='(?<='+startString+').*?(?='+endString+')';
           var regex = new RegExp(rexStr);
           var match = content.match(regex);
           var matchVal = match[0];
           var matchLength=matchVal.length;
           content=content.substring(matchLength+2,content.length);
          //  if(matchVal=='P')content='images/'+detail+'/'+content+'.jpg';
           item.tag=matchVal;       
           item.content=content;
           LoopArray.push(item);
          }
          this.setData({
            LoopArray: LoopArray,
            Title:title,
          });

      } else {
        // 如果未找到匹配的对象，给出相应提示
        console.log('未找到匹配的对象');
      }
    }).catch(err => {
      console.error('查询失败', err);
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})