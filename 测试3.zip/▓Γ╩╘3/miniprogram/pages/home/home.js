// pages/home/home.js
const db = wx.cloud.database()  // 初始化

Page({

  onSearchJump:function(event){
    wx.navigateTo({
      url: '../search/search',
      success:function(){
        console.log("jump!!")
      }
    })
  },

  onInsertTest(){
    wx.showLoading({
      title: '数据加载中',
      mask:true
    })
    db.collection("products").add({
      data:{
       image:"https://s1.ax1x.com/2023/01/31/pS0c7m8.jpg",
       text:"畅游潮韵民间"
      }
      
    }).then(res => {
      console.log(res)
      wx.hideLoading()
    })

  },

  getRandomItems(arr, count) {
    const shuffled = arr.slice(0); // 复制数组
    let i = arr.length;
    const min = i - count;
    let temp, index;
    while (i-- > min) {
      index = Math.floor((i + 1) * Math.random());
      temp = shuffled[index];
      shuffled[index] = shuffled[i];
      shuffled[i] = temp;
    }
    return shuffled.slice(min);
  },

  /**
   * 页面的初始数据
   */
  data: {
    scrollTop: 0,
    tabIndex: 0,
    slideshow: [
      // {id:0, image:"cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/logo/2024-01-26 160229.png"},
      // {id:1, image:"cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/logo/2024-01-26 160216.png"},
      {id:2, image:"cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/logo/2024-01-26 160204.png"},
    ],
    row_slide_list:[
      // {id:0, image:"https://s11.ax1x.com/2023/01/31/pS0gZ11.png", text:"潮剧欣赏", url:"../drama/drama"},
      {id:1, image:"https://s11.ax1x.com/2023/01/31/pS0gK0O.png", text:"数字文化馆",url:"../digitalCenter/digitalCenter"},
      {id:2, image:"https://s11.ax1x.com/2023/01/31/pS0ge6x.png", text:"数字游戏厅", url:"../game/game"},
      {id:3, image:"https://s11.ax1x.com/2023/01/31/pS0gM7D.png", text:"关于我们",url:"../aboutUs/aboutUs"}
    ],
  

    cultureExhibitionList:[],
    recommendContentList:[]

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {    
  const capsule = wx.getMenuButtonBoundingClientRect()
  // const collections = [      
  //   'D_history',
  //   'D_classicalDrama',
  //   'D_creation',
  //   'D_developmentHis',
  //   'D_developmentRec',
  //   'D_legendGuys',
  //   'D_relicAndsites'];

  this.setData({
    capsuleTop: capsule.top
    })
    this.refresh()

    // let allData = [];

    // Promise.all(collections.map(collection => db.collection(collection).get()))
    //   .then(collectionSnapshots => {
    //     collectionSnapshots.forEach(collectionSnapshot => {
    //       collectionSnapshot.data.forEach(item => {
    //         allData.push(item);
    //       });
    //     });
    //     // 获取随机4个数据项
    //     const cultureExhibitionList = this.getRandomItems(allData, 4);
    //     console.log(allData);
    //     this.setData({
    //       cultureExhibitionList: cultureExhibitionList
    //     });
    //     console.log(this.data.cultureExhibitionList);
    //   })
    //   .catch(err => {
    //     // 查询失败，输出错误信息
    //     console.error('查询失败', err);
    //   });






  // db.collection("digitalCenter").get().then(res => {
  //   const cultureExhibitionList = this.getRandomItems(res.data, 4);
  //   console.log(res.data)
  //   this.setData({
  //     cultureExhibitionList: cultureExhibitionList
  //   });
  //   console.log(this.data.cultureExhibitionList)
  // }).catch(err => {
  //   // 查询失败，输出错误信息
  //   console.error('查询失败', err)
  // })

  // db.collection("DailyRecommend").get().then(res => {
  //   const recommendContentList = this.getRandomItems(res.data, 3);
  //   console.log(res.data)
  //   this.setData({
  //     recommendContentList: recommendContentList
  //   });
  //   console.log(this.data.recommendContentList)
  // }).catch(err => {
  //   // 查询失败，输出错误信息
  //   console.error('查询失败', err)
  // })

  
  },

  refresh(){
    const collections = [      
      'D_history',
      'D_classicalDrama',
      'D_creation',
      'D_developmentHis',
      'D_developmentRec',
      'D_legendGuys',
      'D_relicAndsites'];
    let allData = [];
    Promise.all(collections.map(collection => db.collection(collection).get()))
      .then(collectionSnapshots => {
        collectionSnapshots.forEach(collectionSnapshot => {
          collectionSnapshot.data.forEach(item => {
            allData.push(item);
          });
        });
        // 获取随机4个数据项
        const cultureExhibitionList = this.getRandomItems(allData, 4);
        console.log(allData);
        this.setData({
          cultureExhibitionList: cultureExhibitionList
        });
        console.log(this.data.cultureExhibitionList);
      })
      .catch(err => {
        // 查询失败，输出错误信息
        console.error('查询失败', err);
      });
  },



  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {
    
  },

  onPageScroll: function (e) {//监听页面滚动
    this.setData({
      scrollTop: e.scrollTop,
    })
  },



  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})