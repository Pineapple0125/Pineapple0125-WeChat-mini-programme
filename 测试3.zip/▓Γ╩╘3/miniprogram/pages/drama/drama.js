// pages/drama/drama.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tabIndex: 1,
    videoTypeBar: ["宣传记录", "type2", "type3"],
    VideoSelectTab: 0,
    // 板块滑动跳转
    moveStart : 0,
    moveEnd : 0,
    sub_1: [
      {
        id: 1,
        image: "https://i.ibb.co/vBnXtbQ/5cfe623e94775a5f7649a66c91c63e40227cb8c9.jpg",
        title: "《潮韵》",
        introduction: "潮剧韵味，回味无穷，传统精粹，尽显神韵。（引用：小红书@记录生活的谢文冲）",
        time: "2022/02/01",
        click: "100",
        data: "../video/video",
        link: ""
      },
      {
        id: 2,
        image: "image_url_2",
        title: "《潮剧少年》",
        introduction: "潮剧的传承发展离不开少年，有这样一群翩翩少年，英姿勃发，坚韧不拔，苦练唱念做打，学习潮剧功夫，在戏台上演悲欢离合，观抑扬褒贬，舞出戏里的千种姿态，唱出戏中的万般情愁，就是这样一群非凡的少年如浩荡长风扬去潮剧旧尘，掀开潮剧的时代新篇章！ （引用：小红书@腌个透亮）",
        time: "time_2",
        click: "click_2",
        data: "data_2",
        link: "link_2"
      },
      {
        id: 3,
        image: "image_url_3",
        title: "《潮剧从头呾到尾》",
        introduction: "潮剧魅力，古今传承，传统之声，回响千年。（引用：@小红书@长光里）",
        time: "time_3",
        click: "click_3",
        data: "data_3",
        link: "link_3"
      },
      {
        id: 4,
        image: "image_url_4",
        title: "《潮剧妆容》",
        introduction: "浓墨重彩间，潮剧妆容诉说着古老的传说与故事，令人陶醉。（引用：小红书@长光里）",
        time: "time_4",
        click: "click_4",
        data: "data_4",
        link: "link_4"
      },
      {
        id: 5,
        image: "image_url_5",
        title: "《念—潮剧》",
        introduction: "潮剧舞台，演绎人生，悲欢离合，尽在其中。（引用：小红书@林错Lamistake）",
        time: "time_5",
        click: "click_5",
        data: "data_5",
        link: "link_5"
      },
      {
        id: 6,
        image: "image_url_6",
        title: "《记—潮剧》",
        introduction: "潮剧精粹，传承不息，经典之作，世代相传。（引用：小红书@拍写真的福气丸）",
        time: "time_6",
        click: "click_6",
        data: "data_6",
        link: "link_6"
      },
      {
        id: 7,
        image: "image_url_7",
        title: "《“南国奇葩”—潮剧》",
        introduction: "潮剧风华，魅力无限，感受传统，领略艺术。（引用：小红书@叽里咕噜）",
        time: "time_7",
        click: "click_7",
        data: "data_7",
        link: "link_7"
      },
      {
        id: 8,
        image: "image_url_8",
        title: "《念—潮剧2》",
        introduction: "潮剧魅力，无法抗拒，一睹风采，终身难忘。（引用：小红书@放眼未来）",
        time: "time_8",
        click: "click_8",
        data: "data_8",
        link: "link_8"
      },
      {
        id: 9,
        image: "image_url_9",
        title: "《什么是潮剧》",
        introduction: "（引用：小红书@吴个咩）",
        time: "time_9",
        click: "click_9",
        data: "data_9",
        link: "link_9"
      },
      {
        id: 10,
        image: "image_url_10",
        title: "《剧透—潮剧》",
        introduction: "潮剧精粹，传承不息，经典之作，世代相传。（引用：小红书@YANGK）",
        time: "time_10",
        click: "click_10",
        data: "data_10",
        link: "link_10"
      },
      {
        id: 11,
        image: "image_url_11",
        title: "《记—潮剧2》",
        introduction: "潮剧传承，文化瑰宝，传统艺术，永放光芒。（引用：小红书@睡着的球鞋侠）",
        time: "time_11",
        click: "click_11",
        data: "data_11",
        link: "link_11"
      },
      {
        id: 12,
        image: "image_url_12",
        title: "《趣—潮剧》",
        introduction: "潮剧情深，如诗如画，传统艺术，璀璨夺目。（引用：小红书@我听过去那个庄园的人说）",
        time: "time_12",
        click: "click_12",
        data: "data_12",
        link: "link_12"
      },
      {
        id: 13,
        image: "image_url_13",
        title: "《念—潮剧3》",
        introduction: "潮剧情深，感人至深，一曲一情，回味无穷。（引用：小红书@我听过去那个庄园的人说）",
        time: "time_13",
        click: "click_13",
        data: "data_13",
        link: "link_13"
      },
      {
        id: 14,
        image: "image_url_14",
        title: "《鼓动新正》",
        introduction: "红男绿女都欢颜，春回大地人欢乐，姐姐户户庆新年！激昂的鼓乐奏响潮剧的南音古韵。（引用：小红书@晟创娱乐）",
        time: "time_14",
        click: "click_14",
        data: "data_14",
        link: "link_14"
      },
      {
        id: 15,
        image: "image_url_15",
        title: "《潮剧服装》",
        introduction: "（引用：小红书@长光里）",
        time: "time_15",
        click: "click_15",
        data: "data_15",
        link: "link_15"
      },
      {
        id: 16,
        image: "image_url_16",
        title: "《潮剧字调》",
        introduction: "（引用：小红书@长光里）",
        time: "time_16",
        click: "click_16",
        data: "data_16",
        link: "link_16"
      },
      {
        id: 17,
        image: "image_url_17",
        title: "《潮剧唱调》",
        introduction: "潮剧之音，绕梁三日，传统之美，永放光芒。（引用：小红书@长光里）",
        time: "time_17",
        click: "click_17",
        data: "data_17",
        link: "link_17"
      },
      {
        id: 18,
        image: "image_url_18",
        title: "《陈三五娘》演出后台",
        introduction: "画上潮剧妆，仿佛置身于古老的戏曲舞台，感受那份独特的韵味。（引用：小红书@方健生摄影）",
        time: "time_18",
        click: "click_18",
        data: "data_18",
        link: "link_18"
      },
      {
        id: 19,
        image: "image_url_19",
        title: "《潮剧妆容2》",
        introduction: "潮剧妆容，一笔一画皆显匠心独运，亦是美丽永恒的经典。（引用：小红书@戏曲化妆师陈练标）",
        time: "time_19",
        click: "click_19",
        data: "data_19",
        link: "link_19"
      },
      {
        id: 20,
        image: "image_url_20",
        title: "《闽粤新腔—潮剧》",
        introduction: "潮剧之声，震撼心灵，传统韵味，历久弥新。（引用：小红书@中言果然爱）",
        time: "time_20",
        click: "click_20",
        data: "data_20",
        link: "link_20"
      }
    ]

  },



 
  // 触摸开始事件
  touchStart: function(e){
    let sx = e.touches[0].pageX
    this.data.moveStart = sx
  },
  // 触摸滑动事件
  touchMove: function(e){
    let sx = e.touches[0].pageX;
    this.data.moveEnd = sx
  },
  // 触摸结束事件
  touchEnd: function(e){
    let start = this.data.moveStart
    let end = this.data.moveEnd
    console.log(start)
    console.log(end)
    if(start < end - 100){

      if(this.data.VideoSelectTab == 0){
        this.setData({
          VideoSelectTab: 2
        })
      }else{
        this.setData({
          VideoSelectTab: this.data.VideoSelectTab -= 1
        })
      }
      console.log('向右滑，这里可以调用方法，及页面跳转事件')
    }else if(start > end + 100){
        console.log(this.data.VideoSelectTab)
      if(this.data.VideoSelectTab < this.data.videoTypeBar.length-1){
        this.setData({
          VideoSelectTab: this.data.VideoSelectTab += 1
        })
      }else{
        this.setData({
          VideoSelectTab: 0
        })
      }
      console.log('向左滑，这里可以调用方法，及页面跳转事件')
    }
  },

    navbarTap: function(e){
      this.setData({
        VideoSelectTab: e.currentTarget.dataset.idx
      })
    },
  

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})