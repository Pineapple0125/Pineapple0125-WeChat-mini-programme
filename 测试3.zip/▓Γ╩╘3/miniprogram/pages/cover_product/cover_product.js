

import * as THREE from '../../miniprogramThree/test1/threejs/three.weapp.js';
import { OrbitControls } from '../../miniprogramThree/test1/controls/OrbitControls.js';
import { GLTFLoader } from '../../miniprogramThree/test1/loaders/GLTFLoader.js';
import {OBJLoader} from '../../miniprogramThree/test1/loaders/OBJLoader.js'
import {MTLLoader} from '../../miniprogramThree/test1/loaders/MTLLoader.js'


const db = wx.cloud.database()  // 初始化
Page({

  /**
   * 页面的初始数据
   */
    data: {
      tabIndex: 2,
      imgUrls: [
        'cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/infomationPicture/creation/7-1-1.png',
        'cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/infomationPicture/creation/7-1-2.png',
        'cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/infomationPicture/creation/7-2.png',
        'cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/infomationPicture/creation/7-3-1.png',
        'cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/infomationPicture/creation/7-3-2.png',
        "cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/infomationPicture/creation/7-4.png"
      ],
      indicatorDots: false, //是否显示面板指示点
      autoplay: true, //是否自动播放
      interval: 3000, //停留时间间隔
      duration: 1000, //播放时长
      previousMargin: '50px', //前边距，可用于露出前一项的一小部分，接受 px 和 rpx 值
      nextMargin: '50px', //后边距，可用于露出后一项的一小部分，接受 px 和 rpx 值
      circular: true, //是否采用衔接滑动
      currentSwiperIndex: 0, //swiper当前索引
      filteredProducts: [],
      products:[],

      row_slide_list:[
        {id:0, image:"cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/icon/钥匙扣.png", text:"钥匙扣", url:"../creation/creation", index:"70001", type:"D_creation"},
        {id:1, image:"cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/icon/口罩.png", text:"口罩",url:"../creation/creation", index:"70003", type:"D_creation"},
        {id:2, image:"cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/icon/纸扇.png", text:"纸扇", url:"../creation/creation", index:"70002", type:"D_creation"},
      ],


    },
   
    swiperBindchange(e) {
      this.setData({
        currentSwiperIndex: e.detail.current
      })
    },

    firstNavigate:function(event){
      wx.navigateTo({
        url: '../product/product?target=type1',
        success:function(){
          console.log("jump!!")
        }
      })
    },

    secondNavigate:function(event){
      wx.navigateTo({
        url: '../product/product',
        success:function(){
          console.log("jump!!")
        }
      })
    },
    thirdNavigate:function(event){
      wx.navigateTo({
        url: '../history/history',
        success:function(){
          console.log("jump!!")
        }
      })
    },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    db.collection('products').get().then(res => {
      this.data.products = res.data
      this.setData({
        filteredProducts: this.getRandomItems(this.data.products, 6)
      })

    }).catch(err => {
      // 查询失败，输出错误信息
      console.error('查询失败', err)
    })
    // 创建选择器查询
    wx.createSelectorQuery()
      .select('#c') // 选择 Canvas 元素
      .node()
      .exec((res) => {
        // 注册 Canvas
        const canvas = THREE.global.registerCanvas(res[0].node)
        
        // 将 Canvas 的 _canvasId 存储在 data 中
        this.setData({ canvasId: canvas._canvasId })

        // 创建透视相机
        const camera = new THREE.PerspectiveCamera(70, canvas.width / canvas.height, 1, 1000);
        camera.position.z = 500;

        // 创建场景
        const scene = new THREE.Scene();
        scene.background = new THREE.Color(0xAAAAAA);

        // 创建渲染器
        const renderer = new THREE.WebGLRenderer({ antialias: true });

        // 创建轨道控制器
        const controls = new OrbitControls(camera, renderer.domElement);
        // 控制器设置（可选）
        // controls.enableDamping = true;
        // controls.dampingFactor = 0.25;
        // controls.enableZoom = false;

        // 设置相机位置
        camera.position.set(200, 200, 500);
        controls.update();

        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.5);
        directionalLight.position.set(0, 0, 1); // 设置光源位置
        scene.add(directionalLight);

        const ambientLight = new THREE.AmbientLight(0xffffff, 0.5); // 选择适当的颜色
        scene.add(ambientLight);


        // 创建立方体的几何和材质
        const geometry = new THREE.BoxBufferGeometry(200, 200, 200);
        const material = new THREE.MeshBasicMaterial({ color: 0x44aa88 });
        
        // 创建立方体并添加到场景
        // const mesh = new THREE.Mesh(geometry, material);
        // scene.add(mesh);

        let mtlLoader = new MTLLoader();
        mtlLoader.load("https://7069-pineapple-2gzyo2k662e96f3a-1317145063.tcb.qcloud.la/model/%E6%97%A0%E6%A0%87%E9%A2%98.mtl?sign=c37a23b7b9eb4a55d406a230abc3e888&t=1709124785", function(materials){
          materials.preload();
          const loader = new OBJLoader();
          loader.setMaterials(materials)
          loader.load('https://7069-pineapple-2gzyo2k662e96f3a-1317145063.tcb.qcloud.la/model/%E6%97%A0%E6%A0%87%E9%A2%98.obj?sign=4daf0dedbea74c31ef28fb1830334a3f&t=1709126152', function (obj) {
          var model = obj;
          model.scale.set(6400,6400,6400)
          // var model = obj.scene
          // model.scale.set(64,64,64)
          scene.add(obj);
          }, undefined, function (e) {
            console.error(e);
          });

        });
        
        

        // 窗口大小变化时的回调函数
        function onWindowResize() {
          camera.aspect = canvas.width / canvas.height;
          camera.updateProjectionMatrix();
          renderer.setSize(canvas.width, canvas.height);
        }

        // 渲染函数
        function render() {
          canvas.requestAnimationFrame(render);
          // mesh.rotation.x += 0.005;
          // mesh.rotation.y += 0.01;
          controls.update();
          renderer.render(scene, camera);
        }

        // 启动渲染循环
        render()
      })



  },

  onUnload: function () {
    // 在页面卸载时注销 Canvas
    THREE.global.unregisterCanvas(this.data.canvasId)
  },
  // 触摸事件处理
  touchStart(e) {
    // console.log('canvas', e)
    THREE.global.touchEventHandlerFactory('canvas', 'touchstart')(e)
  },
  touchMove(e) {
    // console.log('canvas', e)
    THREE.global.touchEventHandlerFactory('canvas', 'touchmove')(e)
  },
  touchEnd(e) {
    // console.log('canvas', e)
    THREE.global.touchEventHandlerFactory('canvas', 'touchend')(e)
  },
  touchCancel(e) {
    // console.log('canvas', e)
  },
  // 其他触摸事件
  longTap(e) {
    // console.log('canvas', e)
  },
  tap(e) {
    // console.log('canvas', e)
  },
  // 文档级别触摸事件
  documentTouchStart(e) {
    // console.log('document',e)
  },
  documentTouchMove(e) {
    // console.log('document',e)
  },
  documentTouchEnd(e) {
    // console.log('document',e)
  },

  getRandomItems(array, count) {
    const shuffledArray = array.slice(); // 创建数组副本以避免修改原始数组
    let currentIndex = shuffledArray.length, randomIndex, temporaryValue;
  
    // 使用 Fisher-Yates 洗牌算法
    while (currentIndex !== 0) {
      randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex--;
  
      // 交换元素
      temporaryValue = shuffledArray[currentIndex];
      shuffledArray[currentIndex] = shuffledArray[randomIndex];
      shuffledArray[randomIndex] = temporaryValue;
    }
  
    // 返回前count项
    return shuffledArray.slice(0, count);
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})