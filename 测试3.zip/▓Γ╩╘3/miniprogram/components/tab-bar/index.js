const app = getApp()

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    tabIndex: { // 在组件使用的页面通过传递tabIndex的值来选中指定的tab
      type: Number
    },
  },
  data: {
    tabBar:[
      {
        pagePath: "../../pages/home/home",
        name:'Home',
        icon:'icon-home',
        image:'cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/icon/菜单栏/原始/推荐.png',
        imageActive:'cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/icon/菜单栏/选择后/2024-01-26 155437.png',
        index: 0,
      },
      {
        pagePath: "../../pages/game/game",
        name:'Game',
        icon:'icon-bussiness-man',
        image:'cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/icon/菜单栏/原始/游戏厅.png',
        imageActive:'cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/icon/菜单栏/选择后/2024-01-26 155512.png',
        index: 1,
      },
      {
        pagePath: "../../pages/cover_product/cover_product",
        name:'Product',
        icon:'icon-bussiness-man',
        image:'cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/icon/菜单栏/原始/文创亭.png',
        imageActive:'cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/icon/菜单栏/选择后/2024-01-26 155405.png',
        index: 2,
      },
      {
        pagePath: "../../pages/me/me",
        name:'Me',
        icon:'icon-bussiness-man',
        image:'cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/icon/菜单栏/原始/我的.png',
        imageActive:'cloud://pineapple-2gzyo2k662e96f3a.7069-pineapple-2gzyo2k662e96f3a-1317145063/icon/菜单栏/选择后/2024-01-26 155309.png',
        index:3,
      },
    ]
  },

  methods: {
    goto(e){
      if(e.currentTarget.dataset.index!=this.properties.tabIndex){
        // const app = getApp();
        // app.globalData.tabIndex = e.currentTarget.dataset.index
        // this.setData({
        //   index:e.currentTarget.dataset.index,
        // })
        const pagePath = this.data.tabBar[e.currentTarget.dataset.index].pagePath;
        console.log(pagePath)
        // 使用 wx.navigateTo 进行页面跳转
        // setTimeout(function () {
          wx.switchTab({
            url: pagePath,
          });
        // }, 300); // 0.3秒等于300毫秒

      }
    }, 
  },


  
})
